from .apython import run_apython

run_apython()
